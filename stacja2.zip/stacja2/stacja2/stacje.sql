-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Lis 22, 2024 at 09:10 AM
-- Wersja serwera: 10.4.32-MariaDB
-- Wersja PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stacje`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `adresy`
--

CREATE TABLE `adresy` (
  `ID` bigint(20) NOT NULL,
  `miasto` varchar(50) NOT NULL,
  `ulica` varchar(50) NOT NULL,
  `numer` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adresy`
--

INSERT INTO `adresy` (`ID`, `miasto`, `ulica`, `numer`) VALUES
(1, 'Gdaśsk', 'Bydoska', 17),
(2, 'Bydgoszcz', 'Rogodzińskiego', 25),
(3, 'Kraków', 'Tczewska', 55),
(4, 'Tczew', 'Rogalowa', 45),
(5, 'Rzeszów', 'Prosta', 11),
(6, 'Olsztyn', 'Długa', 12),
(7, 'gdansk', 'gdanska', 3),
(8, 'gdansk', 'gdynska', 5),
(9, 'gdansk', 'sopocka', 5),
(10, 'gdansk', 'krakowska', 23),
(11, 'gdansk', 'trakowska', 53),
(12, 'gdansk', 'trotowska', 23);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `stacje_paliw`
--

CREATE TABLE `stacje_paliw` (
  `ID` bigint(20) NOT NULL,
  `nazwa` varchar(50) NOT NULL,
  `adres` bigint(20) NOT NULL,
  `cena` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stacje_paliw`
--

INSERT INTO `stacje_paliw` (`ID`, `nazwa`, `adres`, `cena`) VALUES
(1, 'Orlen', 1, 0),
(2, 'Shell', 2, 0),
(4, 'PB', 4, 4),
(5, 'Norbi', 5, 0),
(6, 'Bell', 6, 0),
(9, 'rafal', 8, 0),
(10, 'looken', 23, 5),
(12, 'ltroken', 123, 7);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `adresy`
--
ALTER TABLE `adresy`
  ADD PRIMARY KEY (`ID`);

--
-- Indeksy dla tabeli `stacje_paliw`
--
ALTER TABLE `stacje_paliw`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `adres` (`adres`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adresy`
--
ALTER TABLE `adresy`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `stacje_paliw`
--
ALTER TABLE `stacje_paliw`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
