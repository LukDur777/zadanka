<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="paliwo.css">
</head>

<body>
    <div id="calosc">

        <div>
            <div id="logo" > 
                <img id="fotadiv "src="barcelona.png" alt="">
            </div>
            <label for="choose">Dostepne filtry</label> <br>
            <input type="text" name="" require> <br>
            <label for="minPrice">Minimalna cena:</label>
        <input type="range" id="minPrice" name="minPrice" min="3" max="10" step="0.1" value="5" oninput="aktualizacjacen()">
        <span id="minPriceValue">3.0</span> PLN
        <div id="label">
        <label for="maxPrice">Maksymalna cena:</label>
        <input type="range" id="maxPrice" name="maxPrice" min="3" max="10" step="0.1" value="8" oninput="aktualizacjacen()">
        <span id="maxPriceValue">10.0</span> PLN
        </div>
            <input type="submit" name="submit" value="szukaj">
            <button onclick="reset()">Reset</button> 

        </div>
        <main>wynik wyszukiwania
       
       
<?php
$host = 'localhost';
$user = 'root';
$db = 'stacje';
$haslo = '';

$pol = new mysqli($host, $user, $haslo, $db);


$sql = 'SELECT stacje_paliw.nazwa, stacje_paliw.cena, adresy.miasto, adresy.ulica, adresy.numer FROM stacje_paliw JOIN adresy ON stacje_paliw.adres = adresy.ID';

$wynik = $pol->query($sql);

if ($wynik->num_rows > 0) {
echo "<table border='4' cellpadding='10' width='400px' color='black'  ;>";
echo "<tr>
    <th>Miasto</th>
    <th>Ulica</th>
    <th>Numer</th>
    <th>Cena</th>
  </tr>";

while ($row = $wynik->fetch_array()) {
echo "<tr>";
echo "<td>" . $row['nazwa'] . "</td>";
echo "<td>" . $row['miasto'] . "</td>";
echo "<td>" . $row['ulica'] . "</td>";
echo "<td>" . $row['numer'] . "</td>";
echo "<td>" . $row['cena'] . "</td>";
echo "</tr>";
}
echo "</table>";
} else {
echo "Brak wyników";
}
$pol->close();

?>
            </main>
        </div>
        </main>
    </div>
    

</body>
<script>
    function aktualizacjacen() {
        let minPrice = document.getElementById("minPrice").value;
      let maxPrice = document.getElementById("maxPrice").value;

        document.getElementById("minPriceValue").innerText = minPrice;
     document.getElementById("maxPriceValue").innerText = maxPrice;

        if (parseFloat(minPrice) > parseFloat(maxPrice)) {
            document.getElementById("minPrice").value = maxPrice;
            document.getElementById("minPriceValue").innerText = maxPrice;
        }
    }

    function reset() {
     document.getElementById("minPrice").value = 5;
        document.getElementById("maxPrice").value = 8;

        document.getElementById("minPriceValue").innerText = "5.0";
    document.getElementById("maxPriceValue").innerText = "8.0";
    }
    </script>
</html>